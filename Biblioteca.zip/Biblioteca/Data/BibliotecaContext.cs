using Biblioteca.Models;
using Microsoft.EntityFrameworkCore;

namespace Biblioteca.Data;

public class BibliotecaContext : DbContext //Relação de herança, tudo que ela tiver a outra tambem tera
{
    public BibliotecaContext(DbContextOptions<BibliotecaContext> options)
    : base (options) { }

    // cada Dbset vira uma tabela no banco
    public DbSet<Livro> Livros => Set<Livro>();
}